from pyrogram.enums import ButtonStyle
# Welcome Feature for VipMusic
import os
import asyncio
from functools import lru_cache
from PIL import Image, ImageDraw, ImageFont
from pyrogram import filters, enums
from pyrogram.types import Message, ChatMemberUpdated, InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram.errors import FloodWait

from VipMusic import app
from VipMusic.utils.database import is_on, set_state, bump, cool, auto_on

# Paths - CHANGE THESE ACCORDING TO YOUR FILES
BG_PATH = "VipMusic/assets/welcome.png"
FALLBACK_PIC = "VipMusic/assets/upic.png"
FONT_PATH = "VipMusic/assets/Arimo.ttf"

BTN_VIEW = "๏ ᴠɪᴇᴡ ɴᴇᴡ ᴍᴇᴍʙᴇʀ ๏"
BTN_ADD = "๏ ᴀᴅᴅ ᴍᴇ ᴛᴏ ʏᴏᴜʀ ɢʀᴏᴜᴘ ๏"

CAPTION_TXT = """
❅────✦ ᴡᴇʟᴄᴏᴍᴇ ᴛᴏ ✦────❅
{chat_title}
▰▰▰▰▰▰▰▰▰▰▰▰▰
➻ Nᴀᴍᴇ ✧ {mention}
➻ Iᴅ ✧ `{uid}`
➻ Usᴇʀɴᴀᴍᴇ ✧ @{uname}
➻ Tᴏᴛᴀʟ Mᴇᴍʙᴇʀs ✧ {count}
▰▰▰▰▰▰▰▰▰▰▰▰▰
❅─────✧❅✦❅✧─────❅
"""

JOIN_THRESHOLD = 20
TIME_WINDOW = 10
COOL_MINUTES = 5
WELCOME_LIMIT = 5

last_messages = {}


@lru_cache(maxsize=1)
def cached_bg():
    return Image.open(BG_PATH).convert("RGBA")


@lru_cache(maxsize=2)
def cached_font(size=65):
    return ImageFont.truetype(FONT_PATH, size)


def circle(im, size=(835, 839)):
    im = im.resize(size, Image.LANCZOS).convert("RGBA")
    mask = Image.new("L", size, 0)
    ImageDraw.Draw(mask).ellipse((0, 0, *size), fill=255)
    im.putalpha(mask)
    return im


def build_pic(av, fn, uid, un):
    os.makedirs("downloads", exist_ok=True)
    bg = cached_bg().copy()
    avatar = circle(Image.open(av))
    bg.paste(avatar, (1887, 390), avatar)
    d = ImageDraw.Draw(bg)
    f = cached_font()
    d.text((421, 715), fn, fill=(242, 242, 242), font=f)
    d.text((270, 1005), str(uid), fill=(242, 242, 242), font=f)
    d.text((570, 1308), un, fill=(242, 242, 242), font=f)
    path = f"downloads/welcome_{uid}.png"
    bg.save(path)
    return path


async def safe_send(func, *args, **kwargs):
    try:
        return await func(*args, **kwargs)
    except FloodWait as e:
        await asyncio.sleep(e.value)
        return await func(*args, **kwargs)
    except:
        return None


@app.on_message(filters.command(["welcome"]) & filters.group)
async def toggle(client, m: Message):
    if len(m.command) != 2:
        return await m.reply_text("**Usᴀɢᴇ:**\n⦿ /welcome [on|off]\n➻ Wᴇʟᴄᴏᴍᴇ Sᴇᴛᴛɪɴɢ.....")
    
    user_id = m.from_user.id if m.from_user else (m.sender_chat.id if m.sender_chat else None)
    if not user_id:
        return
    
    try:
        u = await client.get_chat_member(m.chat.id, user_id)
    except:
        return
    
    if u.status not in (enums.ChatMemberStatus.ADMINISTRATOR, enums.ChatMemberStatus.OWNER):
        return await m.reply_text("**Sᴏʀʀʏ ᴏɴʟʏ ᴀᴅᴍɪɴs ᴄᴀɴ ᴄʜᴀɴɢᴇ ᴡᴇʟᴄᴏᴍᴇ ɴᴏᴛɪғɪᴄᴀᴛɪᴏɴ sᴛᴀᴛᴜs !**")
    
    flag = m.command[1].lower()
    if flag not in ("on", "off"):
        return await m.reply_text("**Usᴀɢᴇ:**\n⦿ /welcome [on|off]\n➻ Wᴇʟᴄᴏᴍᴇ Sᴇᴛᴛɪɴɢ.....")
    
    cur = await is_on(m.chat.id)
    if flag == "off" and not cur:
        return await m.reply_text("**Wᴇʟᴄᴏᴍᴇ ɴᴏᴛɪғɪᴄᴀᴛɪᴏɴ ᴀʟʀᴇᴀᴅʏ ᴅɪsᴀʙʟᴇᴅ !**")
    if flag == "on" and cur:
        return await m.reply_text("**Wᴇʟᴄᴏᴍᴇ ɴᴏᴛɪғɪᴄᴀᴛɪᴏɴ ᴀʟʀᴇᴀᴅʏ ᴇɴᴀʙʟᴇᴅ !**")
    
    await set_state(m.chat.id, flag)
    await m.reply_text(f"**{'Eɴᴀʙʟᴇᴅ' if flag == 'on' else 'Dɪsᴀʙʟᴇᴅ'} Wᴇʟᴄᴏᴍᴇ Iɴ {m.chat.title}**")


@app.on_chat_member_updated(filters.group, group=-3)
async def welcome(client, update: ChatMemberUpdated):
    new = update.new_chat_member
    old = update.old_chat_member
    cid = update.chat.id

    if not new or new.status != enums.ChatMemberStatus.MEMBER:
        return
    if old and old.status == enums.ChatMemberStatus.MEMBER:
        return

    if not hasattr(client, "cached_me"):
        try:
            client.cached_me = await client.get_me()
        except:
            return
    me = client.cached_me

    try:
        await client.get_chat_member(cid, me.id)
    except:
        return

    if not await is_on(cid):
        if await auto_on(cid):
            await safe_send(client.send_message, cid, "**Wᴇʟᴄᴏᴍᴇ ᴍᴇssᴀɢᴇs ʀᴇ-ᴇɴᴀʙʟᴇᴅ.**")
        else:
            return

    burst = await bump(cid, TIME_WINDOW)
    if burst >= JOIN_THRESHOLD:
        minutes = min(60, COOL_MINUTES + max(0, burst - JOIN_THRESHOLD) * 2)
        await cool(cid, minutes)
        await safe_send(client.send_message, cid, f"**Mᴀssɪᴠᴇ Jᴏɪɴ Dᴇᴛᴇᴄᴛᴇᴅ ( x{burst} ). Wᴇʟᴄᴏᴍᴇ ᴍᴇssᴀɢᴇs ᴅɪsᴀʙʟᴇᴅ ғᴏʀ {minutes} ᴍɪɴᴜᴛᴇs.**")
        return

    user = new.user
    file_id = None
    if user.photo and hasattr(user.photo, "big_file_id"):
        file_id = user.photo.big_file_id

    avatar = await safe_send(client.download_media, file_id, file_name=f"downloads/pp_{user.id}.png") if file_id else None
    if not avatar:
        avatar = FALLBACK_PIC

    img = build_pic(avatar, user.first_name, user.id, user.username or "No Username")

    try:
        members = await client.get_chat_members_count(cid)
    except:
        members = "?"

    caption = CAPTION_TXT.format(
        chat_title=update.chat.title,
        mention=user.mention,
        uid=user.id,
        uname=user.username or "No Username",
        count=members
    )

    sent = await safe_send(
        client.send_photo,
        cid,
        img,
        caption=caption,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton(BTN_VIEW, url=f"tg://openmessage?user_id={user.id}", style=ButtonStyle.PRIMARY)],
            [InlineKeyboardButton(BTN_ADD, url=f"https://t.me/{me.username}?startgroup=true", style=ButtonStyle.SUCCESS)],
        ])
    )

    if sent:
        last_messages.setdefault(cid, []).append(sent)
        if len(last_messages[cid]) > WELCOME_LIMIT:
            old_msg = last_messages[cid].pop(0)
            if old_msg:
                await safe_send(old_msg.delete)

    async def cleanup(path):
        if path and os.path.exists(path) and not os.path.abspath(path).startswith(os.path.abspath("VipMusic/assets")):
            try:
                os.remove(path)
            except:
                pass

    asyncio.create_task(cleanup(avatar))
    asyncio.create_task(cleanup(img))